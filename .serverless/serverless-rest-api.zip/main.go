package main

import (
	"context"
	"github.com/aws/aws-lambda-go/events"
	"github.com/aws/aws-lambda-go/lambda"
	"github.com/peterouob/devops_golang/database"
	"github.com/peterouob/devops_golang/router"
	"log"
	"net/http"
)

func HandleRequest(context.Context, events.APIGatewayProxyRequest) events.APIGatewayProxyResponse {
	go func() {
		if err := database.InitDynamoDB(); err != nil {
			log.Println("Error to Init DB", err.Error())
		}
	}()
	router.HandleRouter()
	//if err := godotenv.Load(); err != nil {
	//	log.Println("Error to load .env file:", err)
	//}
	//port := ":" + os.Getenv("PORT")
	////log.Println(gateway.ListenAndServe(port, router.HandleRouter()))
	//log.Println(http.ListenAndServe(port, router.HandleRouter()))
	return events.APIGatewayProxyResponse{StatusCode: http.StatusOK, Body: "Hello world"}
}
func main() {
	lambda.Start(HandleRequest)
}
