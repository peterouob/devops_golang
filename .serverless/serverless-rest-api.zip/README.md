## 確認 aws-configure
## 編寫程式連線AWS 
## 編寫Makefile簡化所有指令
## 編寫dockerfile以便CD

## 編寫gitlab流水線 
    - 一次推送兩個 git
    - https://medium.com/@martina.says/git-push-%E5%90%8C%E6%99%82%E6%8E%A8%E5%88%B0%E5%85%A9%E5%80%8B%E9%81%A0%E7%AB%AF%E5%84%B2%E5%AD%98%E5%BA%AB-54776537575f

## jenkins和gitlab完成完整CICD流水線
## AWS Deploy
## serverless framework 連線AWS
    - 編寫 serverless.yml
    - 更改 makefile
## 使用cloud watch觀看錯誤日誌 (可以連接普羅米修斯)